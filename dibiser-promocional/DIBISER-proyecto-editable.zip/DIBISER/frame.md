---
name: DIBISER — fuerza industrial
preset: coral (brand-adapted)
colors:
  black: "#101820"
  cream: "#F5F7F8"
  blue: "#94DDF5"
  red: "#EF233C"
  yellow: "#FFD12F"
  white: "#FFFFFF"
  secondary: "#BDD1DA"
typography:
  display: {fontFamily: "Barlow Condensed", weight: 700}
  body: {fontFamily: "Inter", weight: 600}
---
# Design direction
Premium industrial motion design. Architectural oversized condensed typography, sharp diagonal color fields, ruler marks and precise callout lines. NOT a dashboard, website or small cards. Strong asymmetry, clear hierarchy, cinematic automotive advertising vehicle imagery. Blue, red and yellow are accents, black and near-white are structural grounds. No gradients added to images; image assets already have studio shading. No filters, blur, decorative glows or bouncy easing.
# Type and safe area
Display 112–210px. Main service text 112–145px. Secondary text 32–42px. Tiny persistent labels 24–26px minimum. Main content x96..1824, y90..900. Any bottom footer y960 is a consciously marked lower-third. Only use text explicitly supplied in packet. Max 3 main copy blocks simultaneously. CSS font face locally in EACH subcomp: Barlow Condensed assets/display.woff2 weight700; Inter assets/body.woff2 weight600. font paths relative to project root used by runtime. Black text on yellow/blue/light; white text on red/black. No yellow/blue text on white.
# Logo, exact real supplied brand
Use official logo from assets/brand-source.png (1672×941) by CSS viewport, not invented lettering: viewport width190 height160 overflow hidden, inner img absolute width1672 height941 left:-1470px top:-14px. Scale wrapper uniformly if needed. It is on white. Can place logo on square white panel. Logo cropping is intentional image overflow; mark only crop img data-layout-ignore.
# Generated vehicle asset sheet
assets/vehicles.png 1536×1024 transparent: loader in TOP y0..506, truck BOTTOM y510..1024. They are promotional illustrations inspired by references. Use viewport width1536 height506 overflow:hidden; inner img width1536 height1024 at top:0 for loader or top:-510px for truck. Wrap viewport in camera group and animate that outer wrapper x,y,scale using GSAP for framed walkthrough. NEVER let second vehicle leak into viewport. All crop img and camera decorative bounds marked data-layout-ignore/allow-overflow where intentional. Ground should be #101820 or #94DDF5. The crop itself may have feathered shadow. Assets are read-only.
# Motion grammar
120 BPM, 0.5 sec beat, 2s bar. Typography lands on 0.5-second grid using crisp 0.3–0.45s power3.out, no bounce. Each 10s equipment scene uses three purposeful camera framings: whole, detail, whole+service payoff. Keep headline fixed during image moves. Rulers/connector lines draw with scaleX or SVG strokeDashoffset, no layout-property tweens. Main scene background is separate full-duration .clip. Styles/scripts INSIDE template, root unique id, and one paused GSAP timeline by exact frame id. No audio in subcomps.

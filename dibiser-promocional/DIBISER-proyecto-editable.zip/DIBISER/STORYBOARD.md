---
format: 1920x1080
duration: 36s
message: "DIBISER: alquiler de maquinaria pesada y venta de agregados"
arc: Fuerza → Alquiler → Agregados → Variedad → Contacto
audience: constructoras y responsables de obra
mode: autonomous
music: none
captions: false
---
## Video direction
Motion graphics industrial de 120 BPM, contraste alto, tipografía condensada grande y recorridos de maquinaria renderizada. Cinco escenas conectadas por cortes al beat y acentos diagonales de marca. Música y voz locales, montadas por el orquestador. Activos generados se usan como ilustraciones comerciales, no como metraje documental de flota. Fuentes de negocio: brief y capturas del usuario.

## Frame 1 — Fuerza que mueve tu obra

- status: animated
- src: compositions/frames/01-hook.html
- duration: 4s
- transition_in: cut
- poster: 2.0s
- scene: Fuerza que mueve tu obra
- voiceover: "Dibiser. Fuerza que mueve tu obra."
- blueprint: compose
- asset_candidates: assets/vehicles.png, assets/brand-source.png
- focal: typography
- roles: headline=hero, vehicle=evidence, accents=structure
- sfx: none

Focal: Huge kinetic headline on black. Scene 1 (0.0–1.0): official logo at x96 y92 on white panel, small DIBISER wordmark beside it; giant word FUERZA at x95 y300, in near-white, ~240px Barlow Condensed, enters beat slam (kinetic-beat-slam). Diagonal yellow engineering stripe right, thin cyan rule. Scene 2 (1.0–2.5): QUE MUEVE at x100 y535 ~170px arrives by chunk on beats, then TU OBRA at x950 y535 or next line, blue/yellow, keep clean and unclipped. No machinery imagery necessary in hook; giant typography is hero. Scene 3 (2.5–4.0): secondary line ALQUILER DE MAQUINARIA PESADA at x100 y795 ~43px Inter, sequential reveal (dynamic-content-sequencing), red thick short underline expands. Final composition confident, no tiny text. Allowed exact text: DIBISER; FUERZA; QUE MUEVE; TU OBRA; ALQUILER DE MAQUINARIA PESADA.

## Frame 2 — Alquiler de maquinaria pesada

- status: animated
- src: compositions/frames/02-loader.html
- duration: 10s
- transition_in: cut
- poster: 5.0s
- scene: Alquiler de maquinaria pesada
- voiceover: "Alquiler de maquinaria pesada. Cargador frontal para el movimiento de tierras y manejo de materiales."
- blueprint: compose
- asset_candidates: assets/vehicles.png, assets/brand-source.png
- focal: vehicle
- roles: headline=hero, vehicle=evidence, accents=structure
- sfx: none

Focal: generated yellow loader and unmissable ALQUILER. Ground black, blue diagonal architectural panel right behind machine. Fixed top-left service overline ALQUILER DE, huge MAQUINARIA PESADA in two stacked lines upper left; keep font112 and headline block under x780 y350, service label at x100 y95. Vehicle wide crop at base x350 y370 scale0.96 (~1474x486), big and clear, all within y900. Scene 1 (0–2.5): whole loader reveal from right then settle; title chunks on beat (dynamic-content-sequencing). Label CARGADOR FRONTAL right above image. Scene 2 (2.5–5.5): purposeful camera approach to bucket, using viewport-change on inner photo camera, frame all bucket and front tire with x/scale; a callout line (svg-path-draw) to bucket with MOVIMIENTO DE TIERRAS on a solid yellow tab, positioned left below headline avoiding vehicle. Scene 3 (5.5–8): smoothly shift camera to cab / hydraulic arm while label MANEJO DE MATERIALES appears on beat; do not overlap two labels. Scene 4 (8–10): camera returns to whole loader, add bottom-safe red bar ALQUILA PARA TU PROYECTO, lettering white. Keep the two service concepts readable >=2secs. User explicitly requested a vehicle visual walkthrough, so purposeful camera movement is central. No claimed specs or capacity. Only this frame output.

## Frame 3 — Agregados para la construcción

- status: animated
- src: compositions/frames/03-truck.html
- duration: 10s
- transition_in: cut
- poster: 5.0s
- scene: Agregados para la construcción
- voiceover: "Y venta de agregados para la construcción, con nuestro volquete Volvo."
- blueprint: compose
- asset_candidates: assets/vehicles.png, assets/brand-source.png
- focal: vehicle
- roles: headline=hero, vehicle=evidence, accents=structure
- sfx: none

Focal: beautiful white and blue Volvo from LOWER half of vehicles.png. Ground near-white with black lower band and light-blue diagonal right zone; dark typography. Fixed top service VENTA DE, huge AGREGADOS and line PARA LA CONSTRUCCIÓN (~80px), left aligned x100 y95..330. Scene 1 (0–2.5): truck whole at x365 y400 scale.92, width1413 height470, appears with right-to-left power3 settle, type lands at .5 sec intervals (dynamic-content-sequencing). Scene 2 (2.5–5): camera moves toward white cab, focused on right portion while retaining engineered silhouette; black tab VOLQUETE VOLVO above camera and cyan marker line (svg-path-draw). Scene 3 (5–7.5): camera pans toward blue/cream tolva (viewport-change), brings in MATERIALES PARA TU OBRA on blue block at lower left or space below headline. Scene 4 (7.5–10): return to full vehicle, bold red underline below AGREGADOS. No claim that vehicle is for sale: VENTA DE AGREGADOS always visible. Do not draw fake specs, capacities or certifications. Use crop y510 height514; top loader never visible. Only this frame output.

## Frame 4 — Materiales para construir

- status: animated
- src: compositions/frames/04-materials.html
- duration: 6s
- transition_in: cut
- poster: 3.0s
- scene: Materiales para construir
- voiceover: "Arena, piedra chancada, afirmado, piedra pilca y hormigón."
- blueprint: compose
- asset_candidates: assets/vehicles.png, assets/brand-source.png
- focal: typography
- roles: headline=hero, vehicle=evidence, accents=structure
- sfx: none

Focal: a rhythmic full-frame typography catalog of the exact aggregate types supplied. Yellow ground, black header AGREGADOS PARA TU OBRA at x100 y95. Layout six generous rows across two columns or a crisp 3x2 typographic grid without cards; main names 74–88px Barlow; black type. Scene 1 (0–2): ARENA FINA and ARENA GRUESA arrive on beats .0 and .5, aligned left column; simple drawn pile silhouettes (SVG abstract pebbles) near each, not photo. Scene 2 (2–4): PIEDRA CHANCADA ½″ and AFIRMADO appear sequentially, secondary line PREPARADO Y BRUTO ~28px below affirmado; black rule strokes across cells. Scene 3 (4–6): PIEDRA PILCA and HORMIGÓN reveal sequentially, red small accents. Use dynamic-content-sequencing and svg-path-draw, keep established items in place. Avoid invented stock quantities/prices. Exact spellings: ARENA FINA, ARENA GRUESA, PIEDRA CHANCADA ½″, AFIRMADO, PREPARADO Y BRUTO, PIEDRA PILCA, HORMIGÓN. All six should remain readable at finish.

## Frame 5 — Cotiza tu proyecto

- status: animated
- src: compositions/frames/05-contact.html
- duration: 6s
- transition_in: cut
- poster: 3.0s
- scene: Cotiza tu proyecto
- voiceover: "Cotiza tu proyecto. Escríbenos a dibiser doce, arroba gmail punto com."
- blueprint: compose
- asset_candidates: assets/vehicles.png, assets/brand-source.png
- focal: typography
- roles: headline=hero, vehicle=evidence, accents=structure
- sfx: none

Focal: the exact email huge and readable. Light blue background, giant black COTIZA TU PROYECTO top-left x100 y130 ~150px. Official real logo in a white crop panel top-right x1560 y110, at scale1.2. Scene 1 (0–1.5): title assembles with kinetic-beat-slam, red short bar grows under COTIZA. Scene 2 (1.5–3): small ESCRÍBENOS centered-left x100 y470 38px, then dibiser12@gmail.com in black Inter 100–112px in single line x100 y555. Email always exact and no telephone/WhatsApp icon. Scene 3 (3–6): dark lower strip y800..930 containing ALQUILER DE MAQUINARIA PESADA + VENTA DE AGREGADOS at 34px in white, separated by yellow slash; small formal company name DISTRIBUIDORA DE BIENES Y SERVICIOS E.I.R.L. at y990 in dark 26px with explicit lower-third annotation. Red yellow blue narrow stripes animate to lock frame. Hold email entirely still and fully readable for final >=3 secs. No exit fade until after 35.7s absolute if any. Intent: unmistakable contact CTA.

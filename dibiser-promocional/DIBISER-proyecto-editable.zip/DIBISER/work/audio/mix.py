"""Master DIBISER: intelligible Spanish voice, beat-timed music and transitions."""
from pathlib import Path
import json, subprocess, re
import numpy as np
from scipy.io import wavfile
from scipy import signal
ROOT=Path('/workspace/work/videos/dibiser-promo'); TMP=ROOT/'work/audio'; ASSETS=ROOT/'assets'
SR=48000; N=36*SR

def run(args):
 p=subprocess.run(['ffmpeg','-hide_banner','-y',*args],capture_output=True,text=True)
 if p.returncode: raise RuntimeError(p.stderr[-3000:])
 return p.stderr
def loudnorm(source,dest,lufs,tp=-1.5,pre=''):
 base=(pre+',' if pre else '')
 stderr=run(['-i',str(source),'-af',base+f'loudnorm=I={lufs}:TP={tp}:LRA=7:print_format=json','-f','null','-'])
 j=json.loads(re.search(r'\{\s*"input_i"[\s\S]*?\}',stderr).group())
 filt=base+f"loudnorm=I={lufs}:TP={tp}:LRA=7:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true:print_format=json"
 result=run(['-i',str(source),'-af',filt,'-ar',str(SR),'-c:a','pcm_s24le',str(dest)])
 return json.loads(re.search(r'\{\s*"input_i"[\s\S]*?\}',result).group())
def read(p):
 sr,x=wavfile.read(p); x=x.astype(np.float64)/(32768 if x.dtype==np.int16 else 2147483648)
 if sr!=SR: x=signal.resample_poly(x,SR,sr)
 return x
def write(p,x): wavfile.write(p,SR,(np.clip(x,-1,1)*2147483647).astype(np.int32))

meta={'title':'Fuerza que mueve tu obra','composer':'Original procedural composition for DIBISER','bpm':120,'duration':36,'sample_rate':SR,'music_license':'Original composition and synthesis; no third-party music samples','narrator':{'engine':'Kokoro-82M ONNX v1.0','voice':'em_alex','language':'es','type':'neural synthetic voice'},'scene_hits':[0,4,14,24,30]}
segments=json.loads((TMP/'voice-segments.json').read_text()); voice=np.zeros(N)
for seg in segments:
 source=ROOT/seg['source']; dest=TMP/f"clean-{seg['id']}.wav"
 avail=seg['end']-seg['start']; speed=max(1,seg['source_duration']/avail)
 pre='highpass=f=75,lowpass=f=11000,acompressor=threshold=0.16:ratio=2:attack=8:release=85:makeup=1.2'
 if speed>1.001: pre+=f',atempo={speed:.6f}'
 loudnorm(source,dest,-18,-3.0,pre)
 x=read(dest); x=x[:int(avail*SR)]
 ramp=min(int(.014*SR),len(x)); x[:ramp]*=np.linspace(0,1,ramp); x[-ramp:]*=np.linspace(1,0,ramp)
 i=round(seg['start']*SR); voice[i:i+len(x)]+=x
 seg['actual_start']=seg['start']; seg['actual_end']=round((i+len(x))/SR,4); seg['retime']=speed
write(TMP/'narration-assembled.wav',voice)
meta['voice_measurement']=loudnorm(TMP/'narration-assembled.wav',ASSETS/'narration.wav',-17.4,-3.0)
meta['music_measurement']=loudnorm(TMP/'music-raw.wav',ASSETS/'music.wav',-20,-3.0,'highpass=f=28,equalizer=f=1800:t=q:w=0.85:g=-2.5')
# SFX are short accents rather than a continuous loudness target.
run(['-i',str(TMP/'sfx-raw.wav'),'-af','volume=0.42,afade=t=out:st=35.6:d=0.4','-ar',str(SR),'-c:a','pcm_s24le',str(ASSETS/'sfx.wav')])
voice=read(ASSETS/'narration.wav'); music=read(ASSETS/'music.wav'); sfx=read(ASSETS/'sfx.wav')
music=music[:N]; sfx=sfx[:N]; voice=voice[:N]
duck=np.ones(N)
for seg in segments:
 start=seg['actual_start']; end=seg['actual_end']
 a=max(0,int((start-.18)*SR)); b=int(start*SR); c=int(end*SR); d=min(N,int((end+.35)*SR))
 duck[a:b]=np.minimum(duck[a:b],np.linspace(1,.46,b-a))
 duck[b:c]=np.minimum(duck[b:c],.46)
 duck[c:d]=np.minimum(duck[c:d],np.linspace(.46,1,d-c))
music*=duck[:,None]
write(ASSETS/'music-ducked.wav',music)
mix=music+sfx+np.stack([voice,voice],axis=1)*.90
write(TMP/'premaster.wav',mix)
meta['master_measurement']=loudnorm(TMP/'premaster.wav',ASSETS/'master.wav',-16,-1.5)
run(['-i',str(ASSETS/'master.wav'),'-c:a','aac','-b:a','256k',str(ASSETS/'master.m4a')])
meta['segments']=segments
meta['master']='assets/master.wav'; meta['html_volume']=1
meta['notes']='Use only master.wav for composed soundtrack in HTML; other WAV files are editable stems. Master is 36 seconds, stereo PCM 24-bit / 48 kHz. Voice dips music by 6.7 dB; 1.8 kHz carve leaves speech intelligible; original music maintains 120 BPM. No phone number.'
(TMP/'audio-meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps(meta,ensure_ascii=False,indent=2))

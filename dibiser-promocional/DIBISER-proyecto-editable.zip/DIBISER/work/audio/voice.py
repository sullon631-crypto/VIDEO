"""Local neural Spanish voiceover, Kokoro ONNX; no API credentials needed."""
import sys, json, pathlib, time
sys.path.insert(0, '/workspace/work/audio-deps')
import numpy as np
import onnxruntime as rt
from kokoro_onnx import Kokoro
from scipy.io import wavfile

ROOT=pathlib.Path('/workspace/work/videos/dibiser-promo')
out=ROOT/'work/audio'
opts=rt.SessionOptions(); opts.intra_op_num_threads=4; opts.inter_op_num_threads=1
session=rt.InferenceSession('/workspace/work/tts-models/kokoro-v1.0.onnx',sess_options=opts,providers=['CPUExecutionProvider'])
k=Kokoro.from_session(session,'/workspace/work/tts-models/voices-v1.0.bin')
segments=[
 {'id':'intro','start':0.45,'end':3.85,'text':'Dibiser. Fuerza que mueve tu obra.','speed':0.73},
 {'id':'loader','start':4.6,'end':13.35,'text':'Alquiler de maquinaria pesada. Cargador frontal para el movimiento de tierras y manejo de materiales.','speed':0.73},
 {'id':'truck','start':14.55,'end':23.35,'text':'Y venta de agregados para la construcción, con nuestro volquete Volvo.','speed':0.70},
 {'id':'aggregate','start':24.45,'end':29.5,'text':'Arena, piedra chancada, afirmado, piedra pilca y hormigón.','speed':0.85},
 {'id':'contact','start':30.25,'end':35.5,'text':'Cotiza tu proyecto. Escríbenos a Dibiser doce, arroba yimeil punto com.','speed':0.94},
]
for item in segments:
 t=time.time()
 a,sr=k.create(item['text'],voice='em_alex',speed=item['speed'],lang='es',sentence_pause=.19,clause_pause=.09)
 item['source_duration']=round(len(a)/sr,4)
 item['source']=f"work/audio/vo-{item['id']}.wav"
 wavfile.write(str(ROOT/item['source']),sr,(np.clip(a,-1,1)*32767).astype(np.int16))
 print(item['id'],item['source_duration'],'sec generated in',round(time.time()-t,1),flush=True)
(out/'voice-segments.json').write_text(json.dumps(segments,ensure_ascii=False,indent=2))

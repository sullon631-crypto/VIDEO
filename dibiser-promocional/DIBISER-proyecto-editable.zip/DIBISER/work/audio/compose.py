"""Original 120 BPM industrial/corporate score and designed transitions for DIBISER.
All waveforms are synthesized here; no samples or third-party music are used.
"""
from pathlib import Path
import numpy as np
from scipy import signal
from scipy.io import wavfile

ROOT=Path('/workspace/work/videos/dibiser-promo')
SR=48000; DUR=36; N=SR*DUR; rng=np.random.default_rng(182)
drums=np.zeros((N,2)); tonal=np.zeros((N,2)); bass=np.zeros((N,2)); fx=np.zeros((N,2))

def filt(x, freq, mode='lowpass', order=2):
 return signal.sosfilt(signal.butter(order,freq,mode,fs=SR,output='sos'),x)

def place(buf, x, when, gain=1, pan=0):
 i=int(when*SR); j=min(i+len(x),len(buf)); cut=max(0,-i)
 if j<=0 or i>=len(buf): return
 i=max(i,0); x=x[cut:cut+j-i]
 if x.ndim==1:
  buf[i:j,0]+=x*gain*np.sqrt((1-pan)/2)
  buf[i:j,1]+=x*gain*np.sqrt((1+pan)/2)
 else: buf[i:j]+=x*gain

def times(dur): return np.arange(int(dur*SR))/SR
def hz(midi): return 440*2**((midi-69)/12)
def edges(x, attack=.004, release=.03):
 a=min(len(x),int(attack*SR)); r=min(len(x),int(release*SR))
 x=x.copy(); x[:a]*=np.linspace(0,1,a); x[-r:]*=np.linspace(1,0,r)
 return x
def kick():
 t=times(.48); f=47+94*np.exp(-t*38)
 body=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*9.5)
 click=filt(rng.normal(size=len(t)),2100,'highpass')*np.exp(-t*190)*.17
 return edges(np.tanh((body+click)*1.3)*.9,.001,.03)
def snare():
 t=times(.32); noise=filt(filt(rng.normal(size=len(t)),950,'highpass'),9500)
 env=(1-np.exp(-t*700))*np.exp(-t*19)
 body=(np.sin(2*np.pi*(185*t+5*(1-np.exp(-t*30))))+.34*np.sin(2*np.pi*340*t))*np.exp(-t*25)
 return edges(noise*env*.6+body*.4,.001,.03)
def clap():
 t=times(.24); x=filt(rng.normal(size=len(t)),[1000,6800],'bandpass')
 e=np.zeros_like(t)
 for off in [0,.014,.028]: e+=np.where(t>=off,np.exp(-np.maximum(0,t-off)*65),0)
 return edges(x*e*.22,.001,.02)
def hat(open=False):
 t=times(.3 if open else .085); noise=filt(rng.normal(size=len(t)),7100,'highpass')
 metal=sum(np.sin(2*np.pi*f*t) for f in [6400,8270,10630])/5
 return edges((noise*.75+metal*.2)*np.exp(-t*(16 if open else 58)),.001,.025)
def tom(f):
 t=times(.3); return edges(np.sin(2*np.pi*np.cumsum(f+f*.5*np.exp(-t*27))/SR)*np.exp(-t*13)+filt(rng.normal(size=len(t)),1800)*np.exp(-t*70)*.3)
def bass_note(note,d=.3):
 t=times(d); f=hz(note)
 x=np.sin(2*np.pi*f*t)+.26*np.sin(2*np.pi*f*2*t)+.10*np.sin(2*np.pi*f*3*t)
 e=(1-np.exp(-t*180))*np.exp(-t*2)
 return edges(np.tanh(x*1.5)*e,.007,.045)
def pluck(note,d=.75,soft=False):
 t=times(d); f=hz(note)
 x=np.sin(2*np.pi*f*t+1.1*np.sin(2*np.pi*2*f*t)*np.exp(-t*9))
 x+=.16*np.sin(2*np.pi*f*2.003*t)+.075*np.sin(2*np.pi*f*3*t)
 e=(1-np.exp(-t*800))*np.exp(-t*(6 if soft else 4))
 return edges(x*e,.002,.09)
def chord(notes,d=2.3):
 t=times(d); stereo=[]
 for side in [-1,1]:
  x=np.zeros_like(t)
  for n in notes:
   f=hz(n)
   for h in range(1,7):
    x+=np.sin(2*np.pi*f*(1+side*.0008)*h*t+h*.23)*(.55**(h-1))/len(notes)
  x=filt(x,1600)
  e=np.minimum(1,t/.17)*np.minimum(1,np.maximum(0,d-t)/.52)
  e*=.87+.13*np.sin(2*np.pi*2*t-.7)
  stereo.append(x*e)
 return np.stack(stereo,axis=1)

# 18 bars in 4/4. D minor -> Bb -> F -> C; final D major resolves positively.
prog=[(38,[62,65,69,72]),(34,[58,62,65,69]),(41,[60,65,69,72]),(36,[60,64,67,74])]
kick_times=[]
for bar in range(17):
 at=bar*2; root,notes=prog[(bar//2)%4]
 if bar>=15: root,notes=38,[62,66,69,74]
 if bar==0: drum_gain=.84
 elif bar==1: drum_gain=.95
 else: drum_gain=1.0
 for b in [0,1.5,2,3.5] if bar>=7 else [0,2,2.75]:
  if bar in [6,11,14] and b>2.5: continue
  when=at+b*.5; kick_times.append(when); place(drums,kick(),when,.65*drum_gain)
 for b in [1,3]:
  place(drums,snare(),at+b*.5,.39*drum_gain,.025)
  if bar>=2: place(drums,clap(),at+b*.5+.009,.34,-.16)
 for n in range(8 if bar>=2 else 4):
  when=at+n*(.25 if bar>=2 else .5)
  place(drums,hat(n%8==7),when,.075 if n%2==0 else .11,(-.3 if n%2==0 else .3))
 if bar>=7:
  for n in [1,5,9,13]: place(drums,hat(),at+n*.125,.042,.56)
 for b,length,octave in [(0,.31,0),(.75,.18,0),(1.5,.22,12),(2,.28,0),(2.75,.16,0),(3.5,.2,7)]:
  place(bass,bass_note(root+octave,length),at+b*.5,.34 if bar>=2 else .23)
 place(tonal,chord(notes),at,.135 if bar<2 else .165)
 # Arpeggios, alternating between left and right. Quarter-note dotted delays.
 for j,n in enumerate([0,2,1,3,2,1,3,2]):
  if bar<2 and j%2: continue
  note=notes[n]+(12 if bar>=7 else 0)
  tone=pluck(note,.85,bar<2)
  gain=.07 if bar<7 else .08
  when=at+j*.25
  place(tonal,tone,when,gain,-.30 if j%2 else .30)
  place(tonal,tone,when+.375,gain*.28,.52 if j%2 else -.52)
  place(tonal,tone,when+.75,gain*.12,-.40 if j%2 else .40)
 # Brief musical turnarounds before each scene transition.
 if bar in [1,6,11,14]:
  for j,f in enumerate([160,130,110,90]): place(drums,tom(f),at+1.5+j*.125,.20+j*.025,(-.35+j*.23))

# A compact melodic signature comes forward on the brand ending.
for start in [14,18,22,30,32]:
 for dt,n,g in [(0,74,.095),(.75,77,.075),(1,76,.085),(1.5,69,.09)]:
  p=pluck(n,1.3); place(tonal,p,start+dt,g,.1); place(tonal,p,start+dt+.375,g*.30,-.36)

# Final button: kick, open fifth and major third, with two seconds for the decay.
place(drums,kick(),34,.65)
place(bass,bass_note(38,1.9),34,.32)
place(tonal,chord([62,66,69,74],2),34,.24)
for n in [74,78,81]: place(tonal,pluck(n,1.9),34,.1)

# Subtle stereo room for tonal parts, and a kick-linked low-end envelope.
for lag,g in [(.097,.09),(.173,.075),(.281,.05)]:
 shift=int(lag*SR); tonal[shift:]+=tonal[:-shift,::-1]*g
duck=np.ones(N)
for at in kick_times:
 i=int(at*SR); t=times(.28); d=1-.27*np.exp(-t*14)
 if i+len(d)<N: duck[i:i+len(d)]=np.minimum(duck[i:i+len(d)],d)
music=drums+tonal*duck[:,None]+bass*duck[:,None]
music=np.tanh(music*1.16)/1.16
music[:int(.025*SR)]*=np.linspace(0,1,int(.025*SR))[:,None]
music[int(35.55*SR):]*=np.linspace(1,0,N-int(35.55*SR))[:,None]**1.4

# Transition sound design: smooth air sweep + low impact + two metallic ticks.
for when in [0,4,14,24,30]:
 t=times(.72); air=filt(rng.normal(size=len(t)),[600,7800],'bandpass')
 env=np.sin(np.pi*np.clip(t/.72,0,1))**2
 whoosh=air*env*(.75+.25*np.sin(2*np.pi*12*t))
 place(fx,whoosh,max(0,when-.36),.11,-.2)
 place(fx,whoosh,max(0,when-.31),.08,.5)
 t=times(1.0); f=42+42*np.exp(-t*12)
 hit=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*7)
 hit+=filt(rng.normal(size=len(t)),[100,1400],'bandpass')*np.exp(-t*24)*.25
 place(fx,edges(hit),when,.34)
 tick=pluck(86,.19)
 place(fx,tick,when+.055,.07,-.35); place(fx,tick,when+.145,.045,.3)

for name,arr in [('music-raw',music),('sfx-raw',fx)]:
 peak=np.max(np.abs(arr)); arr*=.87/max(.87,peak)
 wavfile.write(str(ROOT/'work/audio'/f'{name}.wav'),SR,(arr*32767).astype(np.int16))
 print(name,'duration',len(arr)/SR,'peak',round(20*np.log10(np.max(np.abs(arr))),2))

# SCRIPT — DIBISER

**Voice:** Local Kokoro Spanish, selected by audio worker.
**Voice direction:** Seguro, claro, comercial, natural.

## Line 1 — Fuerza que mueve tu obra (Frame 1)

**Time:** 0 – 4s
**Delivery:** Clara, al ritmo; pausa al final.

    Dibiser. Fuerza que mueve tu obra.

## Line 2 — Alquiler de maquinaria pesada (Frame 2)

**Time:** 4 – 14s
**Delivery:** Clara, al ritmo; pausa al final.

    Alquiler de maquinaria pesada. Cargador frontal para el movimiento de tierras y manejo de materiales.

## Line 3 — Agregados para la construcción (Frame 3)

**Time:** 14 – 24s
**Delivery:** Clara, al ritmo; pausa al final.

    Y venta de agregados para la construcción, con nuestro volquete Volvo.

## Line 4 — Materiales para construir (Frame 4)

**Time:** 24 – 30s
**Delivery:** Clara, al ritmo; pausa al final.

    Arena, piedra chancada, afirmado, piedra pilca y hormigón.

## Line 5 — Cotiza tu proyecto (Frame 5)

**Time:** 30 – 36s
**Delivery:** Clara, al ritmo; pausa al final.

    Cotiza tu proyecto. Escríbenos a dibiser doce, arroba gmail punto com.

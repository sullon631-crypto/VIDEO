---
workflow: product-launch-video
flow: automation
storyboard: no
message: "DIBISER alquila maquinaria pesada y vende agregados para la construcción."
destination: Facebook y presentación comercial
aspect: 1920x1080
language: es-PE
audience: constructoras, contratistas y responsables de obra
length: 36s
angle: recorrido de maquinaria y materiales
narration: minimal
VO_MODE: restructured
---
## Intent
Promocionar Distribuidora de Bienes y Servicios EIRL (DIBISER). Prioridad inequívoca: ALQUILER DE MAQUINARIA PESADA. Recorrido visual de un cargador frontal amarillo y un volquete Volvo con cabina blanca y tolva azul y blanca, según las referencias. El volquete comunica VENTA DE AGREGADOS PARA LA CONSTRUCCIÓN, no venta del vehículo.
## Assets
El usuario suministró capturas de la empresa, lista de agregados y foto de volquete. Recursos de marca locales en /workspace/VIDEO. Facebook devuelve bloqueo, por lo que las referencias y el brief suministrados serán la fuente. No inventar capacidades, certificaciones, precios ni promesas operativas.
## Customizations
Motion graphics de alto contraste. Azul claro, rojo, negro, amarillo y tonos complementarios. Textos sincronizados al ritmo, música y efectos sonoros con mezcla controlada. Correo exacto dibiser12@gmail.com. Sin teléfono. Arena fina, arena gruesa, piedra chancada 1/2 pulgada, afirmado preparado y bruto, piedra pilca, hormigón.
## Decisions
36 segundos, horizontal 1920x1080, elegido para el recorrido amplio de vehículos. Recorridos mediante planos generales, acercamientos y llamadas gráficas; no presentar movimientos inventados como metraje real de la empresa. El usuario autoriza explícitamente crear HTML, revisarlo y renderizar MP4, así que se ejecuta de principio a fin.
